package com.lzb.product.infrastructure.mapper;

import com.lzb.product.domain.entity.Product;
import com.mybatisflex.core.BaseMapper;

public interface ProductMapper extends BaseMapper<Product> {
}
