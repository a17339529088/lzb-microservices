package com.lzb.uaa.domain.service;

import com.lzb.uaa.domain.entity.User;
import com.lzb.uaa.domain.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.query.LdapQueryBuilder;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class LdapAuthenticationService {
    private final LdapTemplate ldapTemplate;
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    
    public User authenticateAndGetUser(String username, String password) {
        try {
            // Build DN for the user
            String userDn = "cn=" + username + ",ou=users";
            
            // Authenticate against LDAP
            ldapTemplate.authenticate(
                    LdapQueryBuilder.query().base("ou=users").where("cn").is(username),
                    password
            );
            
            // Get user attributes including memberOf
            Object ldapEntry = ldapTemplate.lookup(userDn);
            javax.naming.directory.Attributes attributes = null;
            
            if (ldapEntry instanceof javax.naming.directory.DirContext) {
                attributes = ((javax.naming.directory.DirContext) ldapEntry).getAttributes("");
            }
            
            // Extract memberOf attribute to determine roles
            List<String> roles = extractRolesFromLdap(attributes);
            
            // Check if user exists in database
            User user = userRepository.findByUsernameAndSource(username, "LDAP")
                    .orElse(null);
            
            if (user == null) {
                // Create new user
                user = new User();
                user.setUsername(username);
                user.setPassword(passwordEncoder.encode(password));
                user.setSource("LDAP");
                user.setEnabled(true);
                user.setDeleted(false);
                user.setCreatedAt(LocalDateTime.now());
                user.setUpdatedAt(LocalDateTime.now());
                
                // Save user
                user = saveUserWithRoles(user, roles);
                log.info("Created new LDAP user: {}", username);
            }
            
            return user;
            
        } catch (Exception e) {
            log.error("LDAP authentication failed for user: {}", username, e);
            throw new BadCredentialsException("LDAP authentication failed", e);
        }
    }
    
    private List<String> extractRolesFromLdap(javax.naming.directory.Attributes attributes) {
        List<String> roles = new ArrayList<>();
        try {
            if (attributes == null) {
                roles.add("USER");
                return roles;
            }
            
            javax.naming.directory.Attribute memberOf = attributes.get("memberOf");
            if (memberOf != null) {
                String memberOfStr = memberOf.toString();
                
                // Map LDAP groups to application roles
                if (memberOfStr.contains("cn=admins")) {
                    roles.add("PRODUCT_ADMIN");
                } else if (memberOfStr.contains("cn=editors")) {
                    roles.add("EDITOR");
                } else if (memberOfStr.contains("cn=users")) {
                    roles.add("USER");
                }
            }
            
            // Default role if no group found
            if (roles.isEmpty()) {
                roles.add("USER");
            }
        } catch (Exception e) {
            log.warn("Failed to extract roles from LDAP, using default USER role", e);
            roles.add("USER");
        }
        return roles;
    }
    
    private User saveUserWithRoles(User user, List<String> roleNames) {
        // Simplified version - just log for now
        // In production, you'd save user and associate roles in a transaction
        log.info("Saving user {} with roles: {}", user.getUsername(), roleNames);
        // TODO: Implement proper user-role association
        return user;
    }
}
