package com.lzb.uaa.interfaces.controller;

import com.lzb.uaa.domain.entity.Role;
import com.lzb.uaa.domain.entity.User;
import com.lzb.uaa.domain.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/uaa")
@RequiredArgsConstructor
public class UserInfoController {
    private final UserRepository userRepository;
    
    @GetMapping("/userinfo")
    public ResponseEntity<Map<String, Object>> userInfo() {
        Map<String, Object> response = new HashMap<>();
        
        try {
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String username = authentication.getName();
            
            User user = userRepository.findByUsernameAndSource(username, "DATABASE")
                    .orElse(null);
            if (user == null) {
                response.put("code", 404);
                response.put("message", "User not found");
                response.put("error", "USER_001");
                return ResponseEntity.ok(response);
            }
            
            List<Role> roles = userRepository.findRolesByUserId(user.getId());
            List<String> roleNames = roles.stream()
                    .map(Role::getName)
                    .collect(Collectors.toList());
            
            Map<String, Object> userInfo = new HashMap<>();
            userInfo.put("id", user.getId());
            userInfo.put("username", user.getUsername());
            userInfo.put("email", user.getEmail());
            userInfo.put("source", user.getSource());
            userInfo.put("roles", roleNames);
            
            response.put("code", 200);
            response.put("message", "Success");
            response.put("data", userInfo);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            response.put("code", 500);
            response.put("message", "Internal server error");
            response.put("error", "SYS_001");
            return ResponseEntity.ok(response);
        }
    }
}
