package com.lzb.uaa.interfaces.controller;

import com.lzb.uaa.application.dto.TokenResponse;
import com.lzb.uaa.application.service.TokenService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/uaa")
@RequiredArgsConstructor
public class TokenController {
    private final TokenService tokenService;
    
    @PostMapping("/token")
    public ResponseEntity<Map<String, Object>> token(
            @RequestParam("grant_type") String grantType,
            @RequestParam("username") String username,
            @RequestParam("password") String password,
            @RequestParam("client_id") String clientId,
            @RequestParam("client_secret") String clientSecret,
            @RequestParam(value = "auth_type", defaultValue = "DATABASE") String authType) {
        
        Map<String, Object> response = new HashMap<>();
        
        try {
            // Validate client credentials
            if (!"lzb-client".equals(clientId) || !"lzb-secret".equals(clientSecret)) {
                response.put("code", 401);
                response.put("message", "Invalid client credentials");
                response.put("error", "AUTH_001");
                return ResponseEntity.ok(response);
            }
            
            // Generate token
            TokenResponse tokenResponse = tokenService.generateToken(username, password, authType);
            
            response.put("code", 200);
            response.put("message", "Success");
            response.put("data", tokenResponse);
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            response.put("code", 401);
            response.put("message", "Authentication failed: " + e.getMessage());
            response.put("error", "AUTH_003");
            return ResponseEntity.ok(response);
        }
    }
}
