package com.lzb.uaa.infrastructure.repository;

import com.lzb.uaa.domain.entity.Role;
import com.lzb.uaa.domain.entity.User;
import com.lzb.uaa.domain.repository.UserRepository;
import com.lzb.uaa.infrastructure.mapper.UserMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
@RequiredArgsConstructor
public class UserRepositoryImpl implements UserRepository {
    
    private final UserMapper userMapper;
    
    @Override
    public Optional<User> findByUsernameAndSource(String username, String source) {
        return userMapper.findByUsernameAndSource(username, source);
    }
    
    @Override
    public List<Role> findRolesByUserId(Long userId) {
        return userMapper.findRolesByUserId(userId);
    }
    
    @Override
    public Optional<User> findById(Long id) {
        return userMapper.findById(id);
    }
}
