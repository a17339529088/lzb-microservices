# LZB Microservices - Spring Cloud 微服务DEMO

基于Spring Cloud的微服务架构示例项目，实现了完整的认证授权、服务注册发现、API网关等功能。

## 项目简介

本项目是一个完整的Spring Cloud微服务DEMO，包含以下核心功能：

- **多种认证方式**：支持数据库、LDAP、GitHub OAuth2三种登录方式
- **基于角色的权限控制**：USER、EDITOR、PRODUCT_ADMIN三级角色体系
- **服务注册发现**：使用Nacos作为注册中心和配置中心
- **API网关**：统一入口，Token验证，路由转发
- **JWT Token**：基于Redis的Token存储，3小时过期
- **DDD架构**：领域驱动设计，清晰的分层结构

## 技术栈

- **Java**: 17
- **Spring Boot**: 3.2.3
- **Spring Cloud**: 2023.0.3
- **Spring Cloud Alibaba**: 2023.0.1.0
- **MyBatis-Flex**: 1.9.7
- **MySQL**: 8.0
- **Redis**: 7
- **OpenLDAP**: 1.5.0
- **Nacos**: 2.3.0

## 系统架构

```
┌─────────────┐
│   Browser   │
└──────┬──────┘
       │ :7573 (唯一对外端口)
       ▼
┌─────────────────────────────────────────┐
│          lzb-gateway (网关)              │
│  - Token验证                             │
│  - 路由转发                              │
│  - Header传递 (X-User-Id, X-User-Roles) │
└────┬─────────────────────────┬──────────┘
     │                         │
     ▼                         ▼
┌──────────────┐        ┌──────────────┐
│  lzb-uaa     │        │ lzb-product  │
│  (认证服务)   │        │  (产品服务)   │
│  :9999       │        │  :8081       │
└──────────────┘        └──────────────┘
     │                         │
     └────────┬────────────────┘
              ▼
     ┌────────────────┐
     │     Nacos      │
     │  (注册/配置)    │
     │    :8848       │
     └────────────────┘
```

## 服务说明

### 1. lzb-gateway (API网关)
- **端口**: 7573 (对外唯一端口)
- **功能**: 
  - Token验证（检查Redis）
  - 路由转发（/uaa/** → UAA服务，/api/products/** → Product服务）
  - 用户信息传递（通过Header）

### 2. lzb-uaa (认证服务)
- **端口**: 9999 (内部)
- **功能**:
  - 数据库登录（用户名/密码）
  - LDAP登录（企业目录集成）
  - GitHub OAuth2登录（社交登录）
  - JWT Token生成和管理
  - Thymeleaf登录页面

### 3. lzb-product (产品服务)
- **端口**: 8081 (内部)
- **功能**:
  - 产品CRUD操作
  - 基于角色的权限控制
  - 软删除支持

## 角色权限体系

| 角色 | 权限 | 说明 |
|------|------|------|
| USER | 查询产品列表、查询产品详情 | 普通用户 |
| EDITOR | USER权限 + 创建、修改、删除产品 | 编辑者 |
| PRODUCT_ADMIN | EDITOR所有权限 | 产品管理员 |

**角色继承**: PRODUCT_ADMIN > EDITOR > USER

## 快速开始

### 前置要求

- JDK 17
- Maven 3.8+
- Docker & Docker Compose

### 1. 构建项目

```bash
cd lzb-microservices
mvn clean install
```

### 2. 配置GitHub OAuth2（可选）

如需使用GitHub登录，请先申请GitHub OAuth App：

1. 访问 https://github.com/settings/developers
2. 创建新的OAuth App
3. 设置回调URL: `http://localhost:7573/login/oauth2/code/github`
4. 获取Client ID和Client Secret

然后设置环境变量：

```bash
export GITHUB_CLIENT_ID=your-client-id
export GITHUB_CLIENT_SECRET=your-client-secret
```

### 3. 启动服务

```bash
docker-compose up -d
```

等待所有服务启动完成（约2-3分钟），可通过以下命令查看状态：

```bash
docker-compose ps
```

### 4. 访问服务

- **登录页面**: http://localhost:7573/uaa/login
- **Nacos控制台**: http://localhost:8848/nacos (用户名/密码: nacos/nacos)

## API测试

### 1. 数据库登录获取Token

```bash
curl -X POST "http://localhost:7573/uaa/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=password" \
  -d "username=admin" \
  -d "password=admin123" \
  -d "client_id=lzb-client" \
  -d "client_secret=lzb-secret" \
  -d "auth_type=DATABASE"
```

**预期输出**:
```json
{
  "code": 200,
  "message": "Success",
  "data": {
    "accessToken": "eyJhbGciOiJIUzI1NiJ9...",
    "tokenType": "Bearer",
    "expiresIn": 10800
  }
}
```

### 2. LDAP登录获取Token

```bash
curl -X POST "http://localhost:7573/uaa/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=password" \
  -d "username=ldap_editor_1" \
  -d "password=ldap_editor_1" \
  -d "client_id=lzb-client" \
  -d "client_secret=lzb-secret" \
  -d "auth_type=LDAP"
```

### 3. 查询产品列表（需要USER角色）

```bash
TOKEN="your-access-token"

curl -X GET "http://localhost:7573/api/products" \
  -H "Authorization: Bearer $TOKEN"
```

**预期输出**:
```json
{
  "code": 200,
  "message": "Success",
  "data": []
}
```

### 4. 创建产品（需要EDITOR角色）

```bash
curl -X POST "http://localhost:7573/api/products" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "测试产品",
    "description": "这是一个测试产品",
    "status": "ON_SHELF"
  }'
```

**预期输出**:
```json
{
  "code": 200,
  "message": "Success",
  "data": {
    "id": 1,
    "name": "测试产品",
    "description": "这是一个测试产品",
    "status": "ON_SHELF"
  }
}
```

### 5. 权限测试（USER角色尝试创建产品）

使用user_1账号登录获取Token，然后尝试创建产品：

```bash
# 1. 获取USER角色的Token
USER_TOKEN=$(curl -s -X POST "http://localhost:7573/uaa/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=password&username=user_1&password=user_1&client_id=lzb-client&client_secret=lzb-secret&auth_type=DATABASE" \
  | jq -r '.data.accessToken')

# 2. 尝试创建产品（应该失败）
curl -X POST "http://localhost:7573/api/products" \
  -H "Authorization: Bearer $USER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"name":"测试","description":"测试","status":"ON_SHELF"}'
```

**预期输出**: 403 Forbidden（权限不足）

## 测试账号

### 数据库用户

| 用户名 | 密码 | 角色 |
|--------|------|------|
| admin | admin123 | PRODUCT_ADMIN |
| user_1 | user_1 | USER |
| editor_1 | editor_1 | EDITOR |
| adm_1 | adm_1 | PRODUCT_ADMIN |

### LDAP用户

| 用户名 | 密码 | 角色 |
|--------|------|------|
| ldap_user_1 | ldap_user_1 | USER |
| ldap_editor_1 | ldap_editor_1 | EDITOR |
| ldap_adm_1 | ldap_adm_1 | PRODUCT_ADMIN |

## 项目结构

```
lzb-microservices/
├── pom.xml                    # 父POM
├── docker-compose.yml         # Docker编排文件
├── init-db/
│   └── init.sql              # 数据库初始化脚本
├── init-ldap/
│   └── bootstrap.ldif        # LDAP初始化配置
├── lzb-gateway/              # 网关服务
│   ├── src/
│   │   └── main/
│   │       ├── java/com/lzb/gateway/
│   │       │   ├── GatewayApplication.java
│   │       │   ├── config/
│   │       │   ├── filter/
│   │       │   └── exception/
│   │       └── resources/
│   │           └── bootstrap.yml
│   ├── Dockerfile
│   └── pom.xml
├── lzb-uaa/                  # 认证服务
│   ├── src/
│   │   └── main/
│   │       ├── java/com/lzb/uaa/
│   │       │   ├── UaaApplication.java
│   │       │   ├── domain/          # 领域层
│   │       │   ├── application/     # 应用层
│   │       │   ├── infrastructure/  # 基础设施层
│   │       │   └── interfaces/      # 接口层
│   │       └── resources/
│   │           ├── bootstrap.yml
│   │           └── templates/
│   │               └── login.html
│   ├── Dockerfile
│   └── pom.xml
└── lzb-product/              # 产品服务
    ├── src/
    │   └── main/
    │       ├── java/com/lzb/product/
    │       │   ├── ProductApplication.java
    │       │   ├── domain/
    │       │   ├── application/
    │       │   ├── infrastructure/
    │       │   └── interfaces/
    │       └── resources/
    │           └── bootstrap.yml
    ├── Dockerfile
    └── pom.xml
```

## 确认清单

- [x] JDK 17已安装
- [x] Maven 3.8+已安装
- [x] Docker和Docker Compose已安装
- [x] 项目可以成功构建（mvn clean install）
- [x] 所有服务可以通过docker-compose启动
- [x] 数据库自动初始化
- [x] LDAP服务正常运行
- [x] 可以通过CURL命令获取Token
- [x] 可以通过CURL命令调用Product API
- [x] 权限控制正常工作
- [x] 登录页面可以访问

## 故障排查

### 服务启动失败

```bash
# 查看服务日志
docker-compose logs -f [service-name]

# 重启服务
docker-compose restart [service-name]
```

### Nacos注册失败

确保Nacos服务已完全启动（约30秒），然后重启应用服务：

```bash
docker-compose restart lzb-gateway lzb-uaa lzb-product
```

### 数据库连接失败

检查MySQL服务状态和初始化脚本：

```bash
docker-compose logs mysql
```

## 停止服务

```bash
docker-compose down

# 删除数据卷（清除所有数据）
docker-compose down -v
```

## 许可证

MIT License

## 作者

刘志彬 (LZB)
# Test workflow
